//Laniqua Webb - March 5th 2015 - Scalable Data Infrastructure - C201503 Term - Output Assignment


//The Variables that will be used in this code

var myGreeting = "Greeting's!"; //This is a welcome string
var whoMe = "about me"; //String that will be used for talking about me
var topic = "my Code"; //The string that tells the topic
var myChildren = 2; //number variable for the amount of children I have
var run = true; // This boolean is true because I love to run
var skillsLearned = "coding skills";// string that discusses specific skill set
var method = "learn";//string for what the user can expect
var thanks = "Thank you, have a great day!";//ending string

//Output messages will be given to the user

console.log(myGreeting);// welcome output
console.log("Thank you for viewing " +topic+ "!" ); //output for letting the user know what they are looking at
console.log("I am showing off my " + skillsLearned + ".");//output for letting the user know what I am doing
console.log("In addition you will get to " +method+ " a little more " +whoMe+ "!");//output for additional topics provided
console.log("I have a total of " +myChildren+ " young boys.");//outputting my information
console.log("It is " +run+ " I love to run!" );//boolean output
console.log(thanks);//Ending message

//I have tested this code in my browser and there were no syntax errors!







